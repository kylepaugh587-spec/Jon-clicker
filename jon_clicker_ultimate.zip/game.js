let jons = 0;
let souls = 0;

let baseClickPower = 1;
let baseAutoPower = 0;

let multiplier = 1;

const costScale = 1.1;
const soulCostScale = 1.1;

let upgradeCosts = [10, 100, 1000];
let upgradeOwned = [0, 0, 0];

let soulUpgradeCosts = [5, 25, 100];
let soulUpgradeOwned = [0, 0, 0];

function getClickPower() {
  return baseClickPower * multiplier;
}

function getAutoPower() {
  return baseAutoPower * multiplier;
}

function calculateMultiplier() {
  multiplier =
    1 +
    soulUpgradeOwned[0] * 0.5 +
    soulUpgradeOwned[1] * 1 +
    soulUpgradeOwned[2] * 2;
}

document.getElementById("jonButton").onclick = function () {
  jons += getClickPower();
  update();
};

function buyUpgrade(id) {
  if (jons >= upgradeCosts[id]) {
    jons -= upgradeCosts[id];
    upgradeOwned[id]++;
    upgradeCosts[id] = Math.floor(upgradeCosts[id] * costScale);

    if (id === 0) baseClickPower += 1;
    if (id === 1) baseAutoPower += 1;
    if (id === 2) baseClickPower += 5;

    update();
  }
}

function buySoulUpgrade(id) {
  if (souls >= soulUpgradeCosts[id]) {
    souls -= soulUpgradeCosts[id];
    soulUpgradeOwned[id]++;
    soulUpgradeCosts[id] = Math.floor(soulUpgradeCosts[id] * soulCostScale);

    calculateMultiplier();
    update();
  }
}

function getRebirthGain() {
  if (jons < 1000000) return 0;
  return Math.floor(Math.sqrt(jons / 100000));
}

function rebirth() {
  const gainedSouls = getRebirthGain();
  if (gainedSouls > 0) {
    souls += gainedSouls;

    jons = 0;
    baseClickPower = 1;
    baseAutoPower = 0;

    upgradeCosts = [10, 100, 1000];
    upgradeOwned = [0, 0, 0];

    calculateMultiplier();
    update();
  }
}

function formatNumber(num) {
  if (num >= 1e12) return num.toExponential(2);
  return Math.floor(num).toLocaleString();
}

function update() {
  document.getElementById("jons").innerText = formatNumber(jons);
  document.getElementById("souls").innerText = formatNumber(souls);
  document.getElementById("clickPower").innerText = formatNumber(getClickPower());
  document.getElementById("autoPower").innerText = formatNumber(getAutoPower());
  document.getElementById("multiplier").innerText = multiplier.toFixed(2);
  document.getElementById("rebirthGain").innerText = getRebirthGain();

  for (let i = 0; i < upgradeCosts.length; i++) {
    document.getElementById("cost" + i).innerText = formatNumber(upgradeCosts[i]);
    document.getElementById("owned" + i).innerText = upgradeOwned[i];
  }

  for (let i = 0; i < soulUpgradeCosts.length; i++) {
    document.getElementById("soulCost" + i).innerText = formatNumber(soulUpgradeCosts[i]);
    document.getElementById("soulOwned" + i).innerText = soulUpgradeOwned[i];
  }
}

setInterval(function(){
  jons += getAutoPower();
  update();
},1000);

update();
